M.U.G.E.N Effects sprites
-------------------------

M.U.G.E.N       (c) 2001 Elecbyte
                www.elecbyte.com


This version updated: 5 July 2000

This directory contains the sprites required to build
data/fightfx.sff, which has the graphics for hit sparks,
dust graphics and other effects that characters commonly
use.

Unzip these files in work/fightfx under your MUGEN directory.
You will need SprMaker, available from our web page.

From your MUGEN directory, you can type
  sprmaker < work\fight\fight.txt

Edit data/fightfx.air to animate the sparks.
