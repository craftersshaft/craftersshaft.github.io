                Mountainside temple stage - Work files
                --------------------------------------

                M.U.G.E.N        (c) 2001 Elecbyte
                www.elecbyte.com

                Version update: 30 November 2001



  Here is a sample stage that works with M.U.G.E.N.
  This version should be used with M.U.G.E.N ver 2001.11.01.

  Included are the files we used to make the graphics for the
  stage. You will need SprMaker, available from our web page in
  the Mugen Tools package. 

  Unzip this into a directory named work/stages/kfm/ under your
  MUGEN directory. 

  From your MUGEN directory, you can type:

    ./sprmaker < work/stages/kfm/kfm.txt

  to build the sprite stages/kfm.sff.

  You may freely modify and/or distribute Mountainside Temple Stage
  and these work files.
