M.U.G.E.N System Sprites -- "mugen1" motif
------------------------------------------

M.U.G.E.N       (c) 1999-2009 Elecbyte
                www.elecbyte.com


This version updated: 4 August 2009

The sprites in this directory are used to build system.sff for the
"mugen1" (1280x720) motif. You can use them as a starting base for
making a high-resolution motif.

Place these files in a work directory under your MUGEN directory,
e.g. work/mugen1/system/
You will need SprMake2, available from our web page.

From your MUGEN directory, type
  sprmake2 work/mugen1/system/system-sff.def

