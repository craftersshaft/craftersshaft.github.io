M.U.G.E.N Fight-screen sprites
------------------------------

M.U.G.E.N       (c) 2001 Elecbyte
                www.elecbyte.com


This version updated: 5 May 2000

This directory contains the sprites required to build
data/fight.sff, which has the graphics for all you see in the
fight screen, including the life bars, power bars and win icons.

Unzip these files in work/fight under your MUGEN directory.
You will need SprMaker, available from our web page.

From your MUGEN directory, you can type
  sprmaker < work\fight\fight.txt

Edit data/fight.def to set up positions, text and other things.
