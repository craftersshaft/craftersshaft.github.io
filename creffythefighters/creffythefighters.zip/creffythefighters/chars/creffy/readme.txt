===========================
 Creffychan (Creffy the Fighters)
===========================

by craftersshaft


Moveset:
Down, Forward, A: Light Pog
Down, Forward, B: Strong Pog
Down, Forward, A+B: Super Strong Pog